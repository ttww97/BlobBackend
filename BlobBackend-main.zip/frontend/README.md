![tailwind-nextjs-banner](/public/static/images/twitter-card.png)

## Installation

```bash
yarn
```

## Development

Run the development server:

```bash
yarn dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.
